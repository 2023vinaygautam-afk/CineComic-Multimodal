"""Phase 2 unit tests. A fake backend is used, so no Whisper model download is needed."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from src.audio import postprocess as pp
from src.audio.srt_io import read_srt
from src.audio.whisper_asr import AsrError, AsrStage
from src.common.utils import load_config
from src.evaluation import asr_metrics as am
from tests.conftest import ROOT, needs_ffmpeg


# ---- helpers -----------------------------------------------------------------------------
def words(text, start, step=0.3):
    out, t = [], start
    for tok in text.split():
        out.append({"w": " " + tok, "start": t, "end": t + step * 0.9, "p": 0.9})
        t += step
    return out


def raw_seg(text, start, step=0.3, lp=-0.3, ns=0.02):
    w = words(text, start, step)
    return {"start": w[0]["start"], "end": w[-1]["end"], "text": " " + text,
            "avg_logprob": lp, "no_speech_prob": ns, "words": w}


@pytest.fixture
def acfg():
    return load_config(ROOT / "configs" / "phase2.yaml")["asr"]


@pytest.fixture
def cfg2(tmp_path):
    c = load_config(ROOT / "configs" / "phase2.yaml")
    c["data_dir"] = str(tmp_path / "data")
    c["results_dir"] = str(tmp_path / "results")
    c["log_dir"] = str(tmp_path / "logs")
    c["ingestion"]["random_frame_checks"] = 10
    return c


def fake_backend(raw):
    def fn(wav, acfg, log=None):
        assert Path(wav).exists()
        return list(raw), {"language": "en"}
    return fn


# ---- config -----------------------------------------------------------------------------
def test_phase2_config_loads(acfg):
    assert acfg["max_words"] == 12 and acfg["model_size"] == "small"


# ---- post-processing --------------------------------------------------------------------
def test_long_segment_is_split_to_balloon_size(acfg):
    text = ("Well I think we should leave now, because the storm is coming and "
            "nobody wants to be here when it arrives at the old harbour tonight")
    segs, _ = pp.postprocess([raw_seg(text, 10.0)], acfg)
    assert len(segs) >= 2
    for s in segs:
        assert len(s["words"]) <= acfg["max_words"]
        assert s["end"] - s["start"] <= acfg["max_duration_s"] + 1e-6
    joined = " ".join(w["w"] for s in segs for w in s["words"])
    assert joined == " ".join(text.split())                    # no word lost or reordered


def test_split_prefers_comma_and_never_makes_one_word_pieces(acfg):
    text = "If you really want to know the truth, then listen very carefully to me"
    segs, _ = pp.postprocess([raw_seg(text, 0.0, step=0.25)], acfg)
    assert segs[0]["text"].endswith("truth,")
    assert all(len(s["words"]) >= 2 for s in segs)


def test_split_at_sentence_end_and_long_pause(acfg):
    a = raw_seg("Where are you going?", 1.0)
    w2 = words("To the harbour.", a["end"] + 0.1)
    seg = dict(a, words=a["words"] + w2, end=w2[-1]["end"], text=a["text"] + " To the harbour.")
    segs, _ = pp.postprocess([seg], acfg)
    assert [s["text"] for s in segs] == ["Where are you going?", "To the harbour."]

    gap = raw_seg("Hold on", 1.0)
    later = words("one more thing", gap["end"] + 1.5)
    seg = dict(gap, words=gap["words"] + later, end=later[-1]["end"], text="Hold on one more thing")
    segs, _ = pp.postprocess([seg], acfg)
    assert len(segs) == 2


def test_short_fragments_are_merged(acfg):
    raw = [raw_seg("Hey", 5.0, step=0.3),                         # 0.27 s fragment
           raw_seg("wait for me", 5.4, step=0.3)]
    segs, _ = pp.postprocess(raw, acfg)
    assert len(segs) == 1 and segs[0]["text"] == "Hey wait for me"


def test_short_fragment_far_from_neighbours_is_kept(acfg):
    raw = [raw_seg("Hey", 5.0), raw_seg("much later line here", 20.0)]
    segs, _ = pp.postprocess(raw, acfg)
    assert len(segs) == 2


def test_hallucinations_dropped_and_reported(acfg):
    raw = [raw_seg("Thanks for watching", 0.0, ns=0.1, lp=-0.2),    # known phrase
           raw_seg("blah blah blah", 3.0, ns=0.9, lp=-1.8),         # silence + low confidence
           raw_seg("I thanks for watching you every day from afar", 6.0),  # real sentence stays
           raw_seg("Real dialogue stays", 10.0)]
    segs, dropped = pp.postprocess(raw, acfg)
    texts = [s["text"] for s in segs]
    assert "Real dialogue stays" in texts and len(texts) == 2
    reasons = {d["reason"].split(":")[0] for d in dropped}
    assert reasons == {"hallucination_phrase", "no_speech_low_confidence"}


def test_overlapping_segments_become_non_overlapping(acfg):
    a, b = raw_seg("first line of speech here", 1.0, step=0.4), raw_seg("second line now", 2.0)
    segs, _ = pp.postprocess([b, a], acfg, audio_duration=30.0)   # also given out of order
    assert pp.validate_timeline(segs) == []
    assert segs[0]["text"].startswith("first")


def test_segments_clamped_to_audio_duration(acfg):
    segs, _ = pp.postprocess([raw_seg("this runs past the end of audio", 9.0)], acfg,
                             audio_duration=10.0)
    assert segs and all(s["end"] <= 10.0 for s in segs)


def test_missing_word_timestamps_are_estimated(acfg):
    seg = {"start": 2.0, "end": 4.0, "text": " no word times here", "avg_logprob": -0.2,
           "no_speech_prob": 0.01, "words": []}
    segs, _ = pp.postprocess([seg], acfg)
    assert segs[0]["text"] == "no word times here" and len(segs[0]["words"]) == 4


def test_segment_ids_sequential_from_one(acfg):
    raw = [raw_seg(f"line number {i} is here", 10.0 * i) for i in range(1, 5)]
    segs, _ = pp.postprocess(raw, acfg)
    assert [s["segment_id"] for s in segs] == list(range(1, len(segs) + 1))


def test_validate_timeline_detects_problems():
    bad = [{"segment_id": 1, "start": 2.0, "end": 1.0, "text": "x"},
           {"segment_id": 3, "start": 0.5, "end": 3.0, "text": ""}]
    assert len(pp.validate_timeline(bad)) >= 4


# ---- metrics ----------------------------------------------------------------------------
def test_wer_cer_known_values():
    m = am.wer_cer("The cat sat.", "the cat sat down")
    assert m["wer"] == 0.3333 and m["ref_words"] == 3          # 1 insertion / 3 words
    assert am.wer_cer("Don't go!", "dont go")["wer"] == 0.0     # punctuation + apostrophes ignored
    assert am.wer_cer("hello world", "")["wer"] == 1.0


def test_start_time_mae_pairs_by_text():
    segs = [{"text": "Where are you going?", "start": 12.5},
            {"text": "To the harbour.", "start": 15.0}]
    m = am.start_time_mae(segs, [{"text": "where are you going", "start": 12.4},
                                 {"text": "to the harbour", "start": 15.3},
                                 {"text": "completely different words", "start": 40.0}])
    assert m["marks_matched"] == 2 and m["marks_unmatched"] == 1
    assert m["start_mae_s"] == pytest.approx(0.2, abs=1e-3)


def test_hallucination_rate_uses_non_speech_regions():
    segs = [{"start": 0.0, "end": 2.0}, {"start": 5.0, "end": 7.0}, {"start": 9.0, "end": 10.0}]
    m = am.hallucination_rate(segs, [[0.0, 3.0]], 0.5)
    assert m["hallucinated"] == 1 and m["hallucination_rate"] == pytest.approx(1 / 3, abs=1e-3)


# ---- SRT --------------------------------------------------------------------------------
def test_srt_round_trips(acfg, tmp_path):
    from src.audio.srt_io import write_srt
    segs, _ = pp.postprocess([raw_seg("Where are you going?", 12.42),
                              raw_seg("To the harbour.", 15.0)], acfg)
    path = tmp_path / "x.srt"
    write_srt(segs, path)
    back = read_srt(path)
    assert [b["text"] for b in back] == [s["text"] for s in segs]
    for b, s in zip(back, segs):
        assert abs(b["start"] - s["start"]) < 1e-3 and abs(b["end"] - s["end"]) < 1e-3


# ---- stage end to end (fake backend) ------------------------------------------------------
@needs_ffmpeg
class TestStage:
    @pytest.fixture
    def ingested(self, cfg2, make):
        import logging
        from src.common.utils import close_logger
        from src.ingestion.video_ingestion import ingest
        ok, vid = ingest(cfg2, str(make(duration=20)), "t002")
        close_logger(logging.getLogger("cinecomic.t002"))
        assert ok
        return vid

    RAW = [raw_seg("Where are you going?", 2.0), raw_seg("To the harbour.", 5.0),
           raw_seg("Thanks for watching", 9.0)]

    def test_stage_writes_artifacts_and_passes(self, cfg2, ingested):
        stage = AsrStage(cfg2, ingested, transcribe_fn=fake_backend(self.RAW))
        assert stage.execute() is True
        data = json.loads(stage.artifact.read_text())
        assert data["video_id"] == ingested and data["model"] == "small"
        assert [s["text"] for s in data["segments"]] == ["Where are you going?", "To the harbour."]
        assert data["n_dropped"] == 1
        assert set(data["segments"][0]) >= {"segment_id", "start", "end", "text", "words",
                                            "avg_logprob", "no_speech_prob"}
        assert len(read_srt(stage.srt_path)) == 2
        metrics = json.loads(stage.metrics_path.read_text())
        assert metrics["passed"] and metrics["ground_truth"] is False

    def test_gate_passes_with_good_ground_truth(self, cfg2, ingested):
        stage = AsrStage(cfg2, ingested, transcribe_fn=fake_backend(self.RAW))
        gt = {"reference_text": "Where are you going? To the harbour.",
              "timestamp_marks": [{"text": "where are you going", "start": 2.1}],
              "non_speech": [[8.0, 12.0]]}
        stage.gt_path.write_text(json.dumps(gt))
        assert stage.execute() is True
        m = json.loads(stage.metrics_path.read_text())
        assert m["wer"] == 0.0 and m["hallucination_rate"] == 0.0

    def test_gate_fails_on_bad_wer_and_hallucination(self, cfg2, ingested):
        raw = [raw_seg("completely wrong words here", 2.0), raw_seg("music lyrics la la la", 9.0)]
        stage = AsrStage(cfg2, ingested, transcribe_fn=fake_backend(raw))
        stage.gt_path.write_text(json.dumps({"reference_text": "Where are you going",
                                             "non_speech": [[8.0, 12.0]]}))
        assert stage.execute() is False
        reason = json.loads(stage.metrics_path.read_text())["reason"]
        assert "WER" in reason and "hallucination" in reason

    def test_cache_and_config_change(self, cfg2, ingested):
        calls = []

        def counting(wav, acfg, log=None):
            calls.append(1)
            return list(self.RAW), {"language": "en"}
        AsrStage(cfg2, ingested, transcribe_fn=counting).execute()
        AsrStage(cfg2, ingested, transcribe_fn=counting).execute()
        assert len(calls) == 1                                  # second run cached
        cfg2["asr"]["max_words"] = 8
        AsrStage(cfg2, ingested, transcribe_fn=counting).execute()
        assert len(calls) == 2                                  # asr config changed -> re-run

    def test_ingestion_cache_unaffected_by_asr_config(self, cfg2, ingested):
        from src.ingestion.video_ingestion import VideoIngestionStage
        cfg2["asr"]["max_words"] = 8
        stage = VideoIngestionStage(cfg2, ingested, Path("x"), "", "x")
        assert stage.is_cached()

    def test_requires_phase1_first(self, cfg2):
        with pytest.raises(AsrError):
            AsrStage(cfg2, "never_ingested", transcribe_fn=fake_backend([])).run()

    def test_video_without_audio_gives_empty_transcript(self, cfg2, make):
        import logging
        from src.common.utils import close_logger
        from src.ingestion.video_ingestion import ingest
        ok, vid = ingest(cfg2, str(make(audio=False)), "t003")
        close_logger(logging.getLogger("cinecomic.t003"))
        stage = AsrStage(cfg2, vid, transcribe_fn=fake_backend(self.RAW))
        assert stage.execute() is True
        assert json.loads(stage.artifact.read_text())["segments"] == []
