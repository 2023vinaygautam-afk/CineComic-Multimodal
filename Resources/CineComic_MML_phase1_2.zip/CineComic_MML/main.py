"""CineComic-MML entry point.

Usage:
  # Phase 1 only
  python main.py --config configs/phase1.yaml --video clip.mp4 --video-id clip_001
  # Phase 1 + Phase 2
  python main.py --config configs/phase2.yaml --video clip.mp4 --video-id clip_001 \
      --stages ingestion asr
  # Phase 2 only (Phase 1 already done)
  python main.py --config configs/phase2.yaml --video-id clip_001 --stages asr
Later phases will register their stages in STAGES below.
"""
from __future__ import annotations

import argparse
import sys

from src.common.utils import get_logger, load_config, set_seed
from src.ingestion.metadata import IngestionError
from src.ingestion.video_ingestion import ingest

STAGES = ["ingestion", "asr"]          # extended phase by phase


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="CineComic-MML pipeline")
    ap.add_argument("--config", required=True, help="YAML config, e.g. configs/phase2.yaml")
    ap.add_argument("--video", default=None, help="video file path or URL (needed for ingestion)")
    ap.add_argument("--video-id", default=None,
                    help="id such as clip_001 (default for ingestion: SHA-256 prefix)")
    ap.add_argument("--stages", nargs="+", default=["ingestion"], choices=STAGES,
                    help="stages to run, in order")
    ap.add_argument("--force", action="store_true", help="ignore the cache and re-run")
    args = ap.parse_args(argv)

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    video_id = args.video_id

    if "ingestion" in args.stages:
        if not args.video:
            ap.error("--video is required for the ingestion stage")
        try:
            ok, video_id = ingest(cfg, args.video, video_id, force=args.force)
        except IngestionError as exc:
            print(f"INGESTION FAILED: {exc}", file=sys.stderr)
            return 2
        print(f"[ingestion] video_id={video_id} gate={'PASS' if ok else 'FAIL'}")
        if not ok:
            return 1
    elif not video_id:
        ap.error("--video-id is required when ingestion is not in --stages")

    if "asr" in args.stages:
        from src.audio.whisper_asr import AsrError, AsrStage
        log = get_logger(video_id, cfg["log_dir"])
        try:
            ok = AsrStage(cfg, video_id, log).execute(force=args.force)
        except AsrError as exc:
            print(f"ASR FAILED: {exc}", file=sys.stderr)
            return 2
        print(f"[asr] video_id={video_id} gate={'PASS' if ok else 'FAIL'}")
        if not ok:
            return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
