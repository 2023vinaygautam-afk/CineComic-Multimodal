# CineComic-MML

Multimodal video-to-comic system, built one stage at a time. This repository currently
contains **Phase 0 (foundation), Phase 1 (video ingestion) and Phase 2 (Whisper speech recognition)**.

## Setup
1. Install Python 3.10/3.11+ and FFmpeg (`ffmpeg -version` and `ffprobe -version` must work).
2. `python -m venv .venv` and activate it, then `pip install -r requirements.txt`
3. `python setup_project.py` to create the folder skeleton
4. `python env_check.py` -> writes `results/environment_report.json`

## Run Phase 1
```
python main.py --config configs/phase1.yaml --video path/to/clip.mp4 --video-id clip_001
```
Outputs:
- `data/raw/clip_001.mp4`          normalised constant-frame-rate, upright mp4
- `data/metadata/clip_001.json`   metadata (time convention: float seconds, frame = round(t*fps))
- `data/metadata/clip_001.metrics.json`  gate metrics and pass/fail
- `data/audio/clip_001.wav`       16 kHz mono WAV (skipped if the video has no audio)

Exit code: 0 gate passed, 1 gate failed, 2 input rejected.

## Tests
`python -m pytest -q tests`

## Phase 1 gate
frame-count agreement <= 1%, |audio - video length| <= 0.1 s, decode errors = 0,
and the random-frame check finds no (or very few) black/unreadable frames.
Thresholds live in `configs/phase1.yaml`.

## Run Phase 2 (Whisper)
```
python main.py --config configs/phase2.yaml --video clip.mp4 --video-id clip_001 --stages ingestion asr
python main.py --config configs/phase2.yaml --video-id clip_001 --stages asr      # Phase 1 already done
```
The first run downloads the Whisper model (needs internet). Outputs:
- `data/subtitles/clip_001.json`  segments (segment_id, start, end, text, words, avg_logprob,
  no_speech_prob), dropped hallucinations, model, rtf
- `data/subtitles/clip_001.srt`
- `data/subtitles/clip_001.metrics.json`

Evaluation needs a hand-made ground-truth file `data/subtitles/clip_001.gt.json`:
```
{"reference_text": "hand-corrected transcript of the clip",
 "timestamp_marks": [{"text": "where are you going", "start": 12.40}],
 "non_speech": [[0.0, 3.2]]}
```
Without it the stage only checks structure. Model-size study:
`python -m src.evaluation.asr_model_study --config configs/phase2.yaml --video-id clip_001`

Phase 2 gate (suggested): WER <= 15%, start-time MAE <= 0.5 s, hallucination rate <= 5%,
sorted / non-overlapping segments.
