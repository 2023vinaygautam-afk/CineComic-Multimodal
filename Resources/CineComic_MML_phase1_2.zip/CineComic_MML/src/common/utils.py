"""Phase 0 shared utilities: config loader, seeding, logging, artifact paths."""
from __future__ import annotations

import hashlib
import json
import logging
import random
from pathlib import Path

import yaml


class ConfigError(ValueError):
    """Raised when a config file contains unknown or invalid keys."""


# Allowed keys. A value of None means "any value"; a dict means "nested section".
# Later phases extend this schema when they add their own config sections.
CONFIG_SCHEMA = {
    "data_dir": None,
    "results_dir": None,
    "log_dir": None,
    "seed": None,
    "ingestion": {
        "max_duration_s": None,
        "min_duration_s": None,
        "audio_sample_rate": None,
        "force_cfr": None,
        "vfr_tolerance": None,
        "random_frame_checks": None,
        "black_frame_mean": None,
        "max_bad_frame_fraction": None,
        "x264_crf": None,
        "x264_preset": None,
    },
    "gates": {
        "frame_count_rel_diff": None,
        "audio_video_diff_s": None,
        "decode_errors": None,
    },
    "asr": {
        "backend": None,
        "model_size": None,
        "language": None,
        "device": None,
        "compute_type": None,
        "vad_filter": None,
        "beam_size": None,
        "condition_on_previous_text": None,
        "max_no_speech_prob": None,
        "min_avg_logprob": None,
        "hallucination_phrases": None,
        "max_words": None,
        "max_duration_s": None,
        "split_gap_s": None,
        "min_duration_s": None,
        "merge_gap_s": None,
        "merge_max_words": None,
        "timestamp_match_min_ratio": None,
        "nonspeech_overlap_ratio": None,
    },
    "asr_gates": {
        "wer_max": None,
        "start_mae_s_max": None,
        "hallucination_rate_max": None,
    },
}


def _validate(cfg: dict, schema: dict, prefix: str = "") -> None:
    for key, value in cfg.items():
        path = f"{prefix}{key}"
        if key not in schema:
            raise ConfigError(f"Unknown config key: '{path}'")
        sub = schema[key]
        if isinstance(sub, dict):
            if not isinstance(value, dict):
                raise ConfigError(f"Config key '{path}' must be a mapping")
            _validate(value, sub, prefix=f"{path}.")


def load_config(path: str | Path, schema: dict | None = None) -> dict:
    """Load a YAML config and reject unknown keys."""
    with open(path, "r", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh) or {}
    if not isinstance(cfg, dict):
        raise ConfigError("Top level of the config must be a mapping")
    _validate(cfg, schema or CONFIG_SCHEMA)
    return cfg


def config_hash(cfg: dict) -> str:
    """Short stable hash of a config, used for caching and in metrics files."""
    blob = json.dumps(cfg, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha1(blob).hexdigest()[:8]


def set_seed(seed: int) -> None:
    """Seed Python, NumPy and (if installed) PyTorch."""
    random.seed(seed)
    try:
        import numpy as np
        np.random.seed(seed)
    except ImportError:
        pass
    try:
        import torch
        torch.manual_seed(seed)
    except ImportError:
        pass


def get_logger(video_id: str, log_dir: str | Path = "logs") -> logging.Logger:
    """Logger that writes to the console and to logs/{video_id}.log."""
    logger = logging.getLogger(f"cinecomic.{video_id}")
    if logger.handlers:                      # already configured in this process
        return logger
    logger.setLevel(logging.INFO)
    logger.propagate = False
    fmt = logging.Formatter("%(asctime)s | %(levelname)-7s | %(name)s | %(message)s")
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    file_handler = logging.FileHandler(Path(log_dir) / f"{video_id}.log", encoding="utf-8")
    file_handler.setFormatter(fmt)
    console = logging.StreamHandler()
    console.setFormatter(fmt)
    logger.addHandler(file_handler)
    logger.addHandler(console)
    return logger


def close_logger(logger: logging.Logger) -> None:
    """Release file handles (needed on Windows and in tests)."""
    for handler in list(logger.handlers):
        handler.close()
        logger.removeHandler(handler)


def artifact_path(cfg: dict, kind: str, video_id: str, ext: str = "json") -> Path:
    """Return data/{kind}/{video_id}.{ext} and create the parent folder.

    Example: artifact_path(cfg, "audio", "clip_001", "wav") -> data/audio/clip_001.wav
    """
    path = Path(cfg["data_dir"]) / kind / f"{video_id}.{ext}"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path
